from chalice import Chalice, BadRequestError
import boto3
import json

app = Chalice(app_name="triton-app")

# Initialize SageMaker runtime client
sagemaker_client = boto3.client("sagemaker-runtime")


@app.route("/")
def index():
    return {"message": "SageMaker Multi-Model Endpoint API"}


@app.route("/predict", methods=["POST"])
def predict():
    request = app.current_request
    body = request.json_body

    # Validate the input
    if "model_name" not in body or "input_data" not in body:
        raise BadRequestError("Missing 'model_name' or 'input_data' in request body.")

    model_name = body["model_name"]
    input_data = body["input_data"]

    # Specify the SageMaker endpoint
    endpoint_name = "triton-ep"  # Replace with your SageMaker endpoint name

    model_path = f"s3://dry-bean-bucket-c/{model_name}"

    try:
        # Call the SageMaker endpoint
        response = sagemaker_client.invoke_endpoint(
            EndpointName=endpoint_name,
            ContentType="application/json",
            Accept="application/json",
            TargetModel=model_path,
            Body=json.dumps(input_data),
        )

        # Parse the response
        result = json.loads(response["Body"].read().decode("utf-8"))
        return {"model_name": model_name, "result": result}

    except Exception as e:
        app.log.error(f"Error invoking SageMaker endpoint: {str(e)}")
        raise BadRequestError(f"Error invoking model: {str(e)}")

